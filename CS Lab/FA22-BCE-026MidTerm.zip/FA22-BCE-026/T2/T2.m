%======================Question2
clc;clear;close all
num = [9];
den = [1 3 9];

sys = tf(num,den);
kp = 3;
kd = 1;
ki = 2;

Base_controller_num = [kd kp ki]
Base_controller_den = [1 0]
PID_Base_controller = tf(Base_controller_num,Base_controller_den)
%sys_before_tuner = series(PID_Base_controller,sys)
%pidTuner(sys,PID_Base_controller)
sys_with_tuner_values = series(C,sys)
sys_feedback = feedback(sys_with_tuner_values,1)
stepinfo(sys_feedback)
