clc;clear;close all
M = 300;
b = 25;
k = 26 * 2;
num = [1/M];
den = [ 1 b/M k/M];
sys = tf(num,den);
pzplot(sys);  
figure;
step(sys);   
stepinfo(sys)

