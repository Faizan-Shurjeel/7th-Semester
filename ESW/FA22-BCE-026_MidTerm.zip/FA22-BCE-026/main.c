#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/adc.h"
#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_adc_cal.h"
#include "PCF8574_LCD.c"
#include <stdio.h>
#include <string.h>

#define DEFAULT_VREF 1100 
#define NO_OF_SAMPLES 8
#define ADC_CHANNEL ADC1_CHANNEL_6 // ADC1 GPIO34
#define D1 GPIO_NUM_12 // D1 
#define D2 GPIO_NUM_14 // D2 
#define BUTTON GPIO_NUM_27 // Push button pin
#define UART_NUM UART_NUM_2
#define TXD_PIN GPIO_NUM_17
#define RXD_PIN GPIO_NUM_16
#define BAUD_RATE 9600
#define RX_BUF_SIZE 128

void UART_init(void) {
    const uart_config_t uart_config = {
        .baud_rate = BAUD_RATE,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };

    uart_param_config(UART_NUM, &uart_config);
    uart_set_pin(UART_NUM, TXD_PIN, RXD_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    uart_driver_install(UART_NUM, RX_BUF_SIZE * 2, 0, 0, NULL, 0);
}

void send_stream(const char* stream) {
    size_t len = strlen(stream);
    uart_write_bytes(UART_NUM, stream, len);
    printf("TX: Sent voltage data\n");
}


void delay_ms(unsigned int ms){
    vTaskDelay(pdMS_TO_TICKS(ms));
}

uint16_t ADC_result(uint8_t samples){
    uint16_t adc = 0;
    for (uint8_t i = 0; i < samples; i++) {
        adc += adc1_get_raw(ADC_CHANNEL);
    }
    adc /= samples;
    return(adc);
}

void app_main() {
    uint16_t ADC = 0;
    float voltage = 0.0f;
    char voltage_str[10];

    adc1_config_width(ADC_WIDTH_BIT_12);
    adc1_config_channel_atten(ADC_CHANNEL, ADC_ATTEN_DB_12);
    
    UART_init();
    PCF8574_LCD_init();

    gpio_config_t io_conf;
    io_conf.intr_type = GPIO_INTR_DISABLE;
    io_conf.mode = GPIO_MODE_OUTPUT;
    io_conf.pin_bit_mask = (1ULL << D1) | (1ULL << D2);
    io_conf.pull_down_en = GPIO_PULLDOWN_DISABLE;
    io_conf.pull_up_en = GPIO_PULLUP_DISABLE;
    gpio_config(&io_conf);

    // Button GPIO config
    io_conf.mode = GPIO_MODE_INPUT;
    io_conf.pin_bit_mask = (1ULL << BUTTON);
    io_conf.pull_up_en = GPIO_PULLUP_ENABLE;
    gpio_config(&io_conf);

    lcd_command(0x01);
    delay_ms(100);
    cursor_position(0, 0);
    lcd_print("Current Voltage: ");
    vTaskDelay(pdMS_TO_TICKS(2000));

    for(;;){
        ADC = ADC_result(NO_OF_SAMPLES);
        voltage = (float)ADC * 3.3f / 4095.0f;

        sprintf(voltage_str, "%.2fV", voltage);
        cursor_position(1, 0);
        lcd_print(voltage_str);

        if (voltage >= 0.0f && voltage <= 1.0f){
            gpio_set_level(D1, 1); // D1 on
            gpio_set_level(D2, 0); // D2 on
        } else if(voltage >= 1.1f && voltage <= 2.0f){
            gpio_set_level(D1, 0); // D1 off
            gpio_set_level(D2, 0); // D2 on
        } else {
            gpio_set_level(D1, 0); // D1 off
            gpio_set_level(D2, 1); // D2 off
        }

        int button_state = gpio_get_level(BUTTON);
        if (button_state == 0){  
            send_stream(voltage_str);
        }

        delay_ms(200);
    }
}